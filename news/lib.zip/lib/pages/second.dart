import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SecondPage extends StatefulWidget {
  List news = [];
  int index;

  SecondPage(this.news, this.index);

  @override
  State<SecondPage> createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          children: [
            Image(image: NetworkImage(widget.news[widget.index]["urlToImage"]),height: MediaQuery.of(context).size.height,fit: BoxFit.cover,),
            Center(
              child: Text(widget.news[widget.index]["description"],style: GoogleFonts.openSans(fontWeight: FontWeight.bold,fontSize:30,color: Colors.white))),
              Positioned(
                bottom: 100,
                child: Row(
                  children: [
                    Text(widget.news[widget.index]["source"]["name"],style: GoogleFonts.lato(fontSize: 25,color: Colors.white)),
                    SizedBox(width: MediaQuery.of(context).size.width*0.4,),
                    Text(widget.news[widget.index]["publishedAt"],style: GoogleFonts.lato(fontSize: 25,color: Colors.white),)
                  ],
                ),
              ),
              Positioned(
                bottom: 40,
                child: Text(widget.news[widget.index]["content"],style: GoogleFonts.lato(fontSize: 15,color: Colors.white)))
              ],
        ),
      ),
    );
  }
}
