import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:skill_risers/models/coursemodel.dart';

class Apiclient {
  Dio _dio = Dio();
  Future<List> getdata() async {
    String URL =
        'https://raw.githubusercontent.com/akashverma230/flutter_project/main/course1.json';
    //Response res = await http.get(Uri.https("https://raw.githubusercontent.com/akashverma230/flutter_project/main", "course1.json"));
    Response res = await _dio.get(URL);

    // for (var u in res.data) {
    //   CourseModel coursemodel =
    //       CourseModel(u["courseImage"], u["trainer"]["fullName"], u["title"]);
    // }
       var body = jsonDecode(res.data);
    
  
    return body["courses"];
    // var body = jsonDecode(res);
  }
}
