import 'package:flutter/material.dart';

Widget UserCard(double h, double w, Widget wid) {
  return Container(
    height: h,
    width: w,
    child: Card(
      shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(5.0),
  ),
      elevation: 10,
      child: wid,
    ),
  );
}
