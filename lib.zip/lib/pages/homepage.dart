import 'package:flipkart/shared/cards/usercard.dart';
import 'package:flipkart/shared/cards/avatar.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        //   margin: EdgeInsets.all(5),
        //     height: 5,
        //     width: 10,
        //     child: Row(children: [
        //       Text('Search for products'),
        //       IconButton(onPressed: (){}, icon: Icon(Icons.mic)),
        //       IconButton(onPressed: (){},icon: Icon(Icons.camera),)
        //     ]),
        //   )],

        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                //IconButton(onPressed: () {}, icon: Icon(Icons.card_travel)),
                //SizedBox(width: 5,),
                Container(
                    margin: EdgeInsets.all(5),
                    width: 40,
                    child: Image.asset('assets/flipkart_icon.png')),
                SizedBox(
                  width: 10,
                ),
                const Text(
                  'Flipkart',
                  style: TextStyle(
                      color: Colors.blue,
                      fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.bold,
                      fontSize: 30),
                ),
                //IconButton(onPressed: (){}, icon: Image.asset('flipkart_icon.png'),)
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              margin: EdgeInsets.all(5),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5), border: Border.all()),
              child: Row(
                children: [
                  SizedBox(
                    width: 80,
                  ),
                  Text(
                    'Search for products',
                    style: TextStyle(color: Colors.grey, fontSize: 20),
                  ),
                  SizedBox(
                    width: 27,
                  ),
                  IconButton(
                      onPressed: () {},
                      icon: Icon(
                        Icons.mic,
                        color: Colors.grey,
                      )),
                  IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.camera_alt,
                      color: Colors.grey,
                    ),
                  )
                ],
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  UserCard(
                      MediaQuery.of(context).size.height * 0.20,
                      MediaQuery.of(context).size.width * 1,
                      Image.asset('assets/boat.jpg')),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.20,
                      MediaQuery.of(context).size.width * 1,
                      Image.asset('assets/AC.jpg')),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.20,
                      MediaQuery.of(context).size.width * 1,
                      Image.asset('assets/fashion.jpg')),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.20,
                      MediaQuery.of(context).size.width * 1,
                      Image.asset('assets/fireboltt.jpg')),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.20,
                      MediaQuery.of(context).size.width * 1,
                      Image.asset('assets/oneplus.jpg')),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.20,
                      MediaQuery.of(context).size.width * 1,
                      Image.asset('assets/asus.jpg'))
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              children: [Avatar('Supercoin',Image.network('data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUSEhMVFhUVFxUVGBYVFxcVFxcaFhYXFxUXGBUYHSghGBolGxgVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGhAQGy0mICUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOkA2AMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAABgQFAQMHAv/EAEAQAAEDAQQGCQIEBAYCAwAAAAEAAgMRBAUhMQYSQVFhcRMiMoGRobHB0UJSQ2Jy4SNTkvAVgqLC0vEzNBQWsv/EABoBAAIDAQEAAAAAAAAAAAAAAAAEAgMFAQb/xAA3EQABAwEFBAkDAwQDAAAAAAABAAIDBAURITFBEhNRoSJhcZGxwdHh8BQygRUzQiMkUvFDorL/2gAMAwEAAhEDEQA/AO4oQhCEIQhCEIQsVQhZWFGt1tjibrSODd288htSreWlT3VbCNQfcaF3cMh5pSorYYB0zjwGasZE5+SbLTamRir3Bo4lUlr0sibhG1z+PZb54+STpZXONXOJO9xqfEqRY7ull7EbiN9KN/qOHgsaS1p5Tswtu5lMima3F58lZWjSmd3Z1WDgKnxKgTXtO7OV/caeitrNolIe29reAGsfFWUWicI7Tnu7wB5BR+lr5vuJ/Ju5eylvIW5eCTnSuObnHmSfUrWn9mjlmH4debnH3Xv/AACzfym+fyu/o05xLhz9Fz6pnBIDZXDJzhyJHupMV6ztylf3mvrVOb9HLMfw6cnOHuos2iUJ7Lnt76+qP0urZixw/BI9EfURnMclTWfSidva1X8xTzCtrLpZEcJGuZxHWb5Y+Sg2nRJ47Dw7g4EHxVNa7umi7cZA30q3+oYLm/r6b7ryOvEd+aNiF+S6FZrUyQVY4OHAqQuWRSuaatJB3g0Kv7t0pe3CYa4+4YO+Cnae2I3YSC7r09VW+mcPtxTqhRLDb45m60bgd42jgRsUqq12uDheDeErdcsoQhSQhCEIQhCEIQhCEIQhCwgoQhL196RtiqyKjn7T9Lfk8FA0g0hLqxwmgyc8ZneG7hxS7DE5xDWgknIDNYVbahB3cGfEeATcVPf0nrNptDpHFz3FxO0+24KfdlxyzYgarfud7Dar659Gmso+ajnZ6ubW/wDIq3t14RwjrHHY0ZnuVMNmgDe1TrhwJ8T5KbpyTsRi/wCaKJd2j0MVCRru+52PgMgptpt8UQ6zgOG3wCWLff8AJJg3qN4Z95+FUPkG04+JUJLZhhGxSsv68h6nvU20bndKU3JotGkzR2GF3Fx1R8qBLpHMctVvIV9VQOn3BeDKd6zpLQrZM33Dqw9+avbDA3IX81cPvec/iO7qBeP8Tm/mO8VUax3rFUuXTnOQ95UwYxk0K7Ze84/Ed30KlRaRzDPVdzFPRLYcd5XoSnepNqKpmLZD3nzXC2J2bU4WfSdp7bC3i06w9irezW6OXsuB4bfArnbZ963MkGw4+BT8Vt1Mf7gDh3HlhyVTqOJ/2m5OVv0fhlxA1Hb24eIyKVLzuOWDEjWb9zfcbFPsN/Sx4OOu3jn4/KZrBeMcw6px2tOBHcn2/RWh9nRfz7sil3NmgzxHz8hc7s1odG4OY4tI2j04hOFy6RtkoyWjX5A/S74PBeb40ba+r4aNdnq5NP8AxKUJoXMJa4EOGYKVvqbPfxae4+h7lPoTjr5rqVVlJ2j2kJbSKY1bk15zG4O3jinAFegpqqOoZtM/I1CSkjLDcVlCEJlQQhCEIQhCwUIQUn6T33rVhjOAwe4bfyg7t6n6UXt0TeiYeu4Yn7W/JSdDEXODWipJoAsK1K0g7iPPX0Cbp4rxtuXuyWV0rgxgqT5cTuCe7mudlnbhi89p3sNwRcl1izspm84ud7DgFWX7fNaxRHDJzt/AfK5FFFZ8W+m+7QeQ8zoukundsMyUi97+DasioXZF2wct5StNNUlziSTtOa1ySU5qM41WDUVMtW7akOGg0HziU8xjIRc3Pitj5SeC1oQoBoGS4STmhCEKS4hC22WyvkdqsaXHh7nYmW79E9szq/lbl3u+EzT0k0/2DDjkFW+RrM0qgVwHgFJbdsxFRFJT9JXQ7JYo4hSNgbyGPipS1o7EF3Tf3e6WdVnQLlckZaaOBB3EEHwK8ro973e2eMtIx+k7QVzlzaEg5jArNrqJ1M4Y3g5HsV8UokHBe2SkcVKhloQ5pII2jMKCstNFmuj1GaabJdgU6XPf2tRktA7IOyB3V3FTb4uhlobjg8dlw2cDvCR45K80x3DfNKRSHDJrjs4FbdDaQkH09XjfkT5+RSs9Nd/UiSxbLK6J5Y8UI8CN4O0K+0ZvvVIhkPVODHHYT9J4blfX3dbbQymTx2XbuB4FIE8JY4scKEGhCjNFJZ8wezEePUfnWotcJmXHNdSWUu6LXt0jeieeu0YH7m/ITCvRwTNmjD2ZFIvYWG4rKEIVyihRbwtbYo3SOyaPE7AOZUlJmmFv1niEHBmLv1EYeA9UpW1AghL9ch2qyNm265UNqtDpHue41LjX9uSbdFLq1G9M8dZw6tdjTt5lUNwXd08oB7Les72HenW87aIYy7bk0byclj2bCAHVUuQvPqfRNTuJIjbr8uVZpHemqOiYese0RsG7mUqSyU5rZPKSS5xqTieJUEmqxqmodVymR2QyHAfMU4xghZsjPVBQhC4uIQhC4uIVpctzutDtzBm7fwG8rXc11m0SauTRi47huHEroFnhaxoa0UaBQBa1nWfv+nJ9vj7JeebY6Iz8FrsVjZE3VjaAPM8SdpUlZXlzqL04aGi4ZLPJWVlLt4aUxsNGNMhG0GjfHatMemDPqicORB+Em60aZrtkvHNWiGQi+5M5XNL1p00tMukf/wDo/ur+16XVFIozU/U4jDuGaV3GpJOZxKx7Vq45g1sZvuxvTNPE5pJIWEIQsdNIUmJ9eajIBoq3s2gpscWm9Oujl6awETz1h2SdoGzmF40qurXb0zB12jrU+po9wluCUghzTQjEcCnm67aJow7bk4bjt/vit6zagVcJppswMD1ce0eCTqY904SsyXPLNO6Nwe00LTUfHJdHu61iaNsjdoxG47R4pH0iu7oZSB2HdZvuO73CnaH2/VkMROD8R+oD3HooWfK6mnMEmuH5071yZokZtt+BOqFgIXpkitNsnEbHPOTQSuZzSlzi45uJJ78SnDTO1asTYxm92PJuPrqpXuqy9LMxmwuFeQxPkPNebtaQyzthbp4lPUzdlpeU46MWHooQSOs/rH/aPD1VPpJbdeXVHZZh37T7JmvCfoonO3DDnkEgSvwJ2+5XLZkEMLKVmufYPU3qdE3ac6V2i0TvqeS1oQsVouFyYJvN6EIQuriF7s8TnuDGirnGgC8J10XuromdI8dd42/S3YOZzTdHSmok2Rlr2KuWQMberK6bA2CMMGebjvO0qchFV7BjGsaGtyCzCbzeVrmkDQXOIAAqSdlEj37frpzqsq2PdkXcTw4L3pJfBmd0bD/Daf6iNvIKjXnbRtAyHdRno6nj85p2CG7pOzQhCFjJpCEIQhCEIQhCEIXULZC6h5q+0dtvRyhp7L8O/YfbvS6pkTqgHb8KDZDBK2VuisDRI0sKctJrD0sJoOszrDuzHgkOKQtIcM2kEcxiF0i7bR0sTXbxjzyKQb2svRTPZsBqORxHlh3LdtZgOxUMyP8AsFIU5I2mFdCsVoEkbXjJwBQqTQy01jdGfodUcnY+tVhbdNNvomv4jnrzSr27LiFVaYz60+r9jQPHE+y3aF2esj3/AGtoOZ/6VTfcutPKfzkeGHsmjQyKkLnfc8+VB8rCpv61eXHiT3YDyTknRhu7FjS2ejWMH1EuPJv7lKNoOxX2lMtZ6fa0DxqfdL0xxKzrQk3ta86DDu970zCNmADivCEIS6EIQhCFa6N2DpphXss6zvYePougqk0VsmpAHbX9Y8vp8ldr11m0+5gF+ZxPl3BZs79p6wlvSy89RvRMPWeOsdzfk/KYnOoKnYuZ2+1GWR0h+o1HAfSPBV2rUmKLZbm7w1XaePadedFoQhC8rctFCEIXUIQhC4hCEIQhCEIQhC3Wc5haV6iOIUZBe0hSYbinLRKerXs3EOHI5+Y81X6a2ej2SfcC3wxHqjReWk9PuaR4Y+ysdM4qwB32vHnh8LdpzvrLIObb+R9EpKNip7VS6IT6s+rse0jwxCFX3PLqzxH87R44e6FdZdSGQlp0J8lVUx3vv6lHndVzjvc4+JJT5ou2llj46x8XOSAuh6N/+tF+n3KXsbGdx6vMKyq+wBK99urPJzp4BUrsyre9f/NJ+oqnKxXm+eQ9Z8U6RdG0dSEIQuqCEUrhvwQiq6hdShjDWhoyAA8FsUWwWkSxte3Jwry3hSV7thBaCMlj46ry9tQQcjh4pOn0SkBOo9pbsrUGnFOiFRUUkVRdvBl+FYyRzPtSYzRGXbIwdxKlR6Hj6pT/AJWgetU0oVDbLpR/HmVIzyHVUEeikAz13c3U9AFKZo/Zh+EDzJPqVaLKvbR07cmDuUDI86lV/wDgtn/ks8FHn0es7h2NU72mh+FcIUnU8ThcWDuC4HuGq55fV0Os5GOsw5O47jxVYuj3xZukhe3bQkcxiFzcFeZtKlbTyjZyPJPwSF7ccwsoQhZyvQstOIWEBCAru5XUnj/VRMuk7a2WTgGnwcCla6//ADR/qCbdIf8A1pf0la9j40Uw7fBUVn7zT8zXPYnUc07iD4EIXlZWY15aFcQvUzaOcNziPAlPmizq2WPhrDwcQk2+YtWeUfnJ8cfdNGhklYC37XnzoflatldCrc3qI7il6jGMHsVJfbaTyfq9Qqd2ZTDpTHSev3NB9vZL0wxKyKhmxVSN6z6psG+Jp7F5QhCiooQhCEK1uO+HWd1DjGc27vzDjwTvY7YyVutG4OHA4jgRsK5mvUUrmmrSWneDRadHaT4BsnFvgqJKcPN4zXVELnsWkFob+JXmAV7OklpP1j+kLUFswcD3Jf6V/Un9YJXOZb5ndnK7uw9FEkne7tOceZJVb7bj/iw966KU6ldLktTG5vaObgER2pjuy9p5OBXMNULACp/W3f4Dv9lL6Tr5e66ssqk0UtDnwDXJNCWgnaArtbsMolYHjUJVzdkkFYK5Y8YkbifVdRe6gJXLCa478fFYltn9sdqapNfwhCELATiFloxWF6iGIXHG4LoxKuLmbWeP9VfBM+k7qWWTiAPFwCodGI6zg/a0n291Z6ZSUgDfue3yqfYLZswbFnyP43+FyWqjfUNHYkuJtXAbyB4miFKuiPWniH52nwNfZYS1LSumYXDjcpSS7BuVhpfBqz633tB7xgVJ0JtFHvZ9wDh3Gh9Qp2mlmrG2QfQ6h5O/eiWbotXRTMfsDqHkcD5HyTM39vaG1oTf3+6g3pw3Jn0tgq1j9xLT35eY80pWgZFdEvKz9LE5u8Yc8wufytqCEtbUW7qhIMnDww9FdRu2oi3goqEISKmhCELiEIQhdQhCEIQhCEIQhSrusD53hje87GjeV6uu7Xzu1WDAdpxyb+/BPt2XcyBmozmSc3HeVoUNnuqDtO+0c+xUTTBmAzW2x2ZsTGsbk0U/crfVCj2y1NiY57zQNH/QHFer6LG8APBZ+ZVVpVePRxagPWkqOTfqPt3pHUm8ba6aQyO25DcNgUZeQrqr6iUuGWQ7PdaUMew245oQhCSVqFus42rSpcTaBVTG5tysiF7kz6IwYPk3kNHdifXyULTa0VeyPcC49+A9CmS67N0UTW7QKnmcSkK+bV0sz37K0HJuA+e9eiqR9NQMh1OfifJIMO8nL9PgU7RCDWtFdjGk+w9UK30Ks1I3yH6nUHJv7k+CE/ZcYZTNv1xVNQb3m5Xlus4kjcw/UCPhc0ljLSWnMEg8xguppK0vsGpJ0oHVfnwcPkeiXtmn2oxKNMD2H3U6V9x2eKvtG7d0sAqeszqu7sj3iiotIbH0cpcOy/rDn9X98VD0dvHoZcT1H9V3Dcf73pxvaxCaMt2jFp4/vkqS39Qotn+bfnMKbHbia/Q/ORXPJmUPNeFMmiOLSKEYcioZC87G68XHNPyNuN4QhCFaq0IQhcQhCFKsV3SzGkbCR9xwaOZUmNc47LReVwkDEqIru5tH3zUc+rI/9TuQ2Dir26dG2R0dJ135/lHIbe9XwW7R2R/Kbu9UpLU6M71oslmZG0MY0ADd6lb0LxI8NBc4gAYknABboAaLhkk0SPDQSTQDEk7EhX9e5nfQYRtPVG/8xW3SC+zOdRlRGO4u4nhwVKvOWlaG9/pRno6nj7J6CHZ6RzQhCFjppCEIAqhC9wsqVe6PWLpJQSOqzrHnsHj6KshjyaBUnzKebosIhjDfqOLjx/ZM2ZS/VVG0ftbz4DzK5UybqO7UrRpHbeigdQ9Z3Vb35nuCQ42FxDRmSAOZwCs9JLx6aXqnqMq1vH7j5eSk6H2DXk6Ujqx5cXEew9k5VvNZViNuQw9Sl4xuo9optsFmEUbYx9IA+UKSEL07QGgAJA3lZUO87GJo3Rnbkdx2HxUxYK45ocC05FdBuXLbRCWOLHChaaEJx0WvXpGdE89dgw/M35GS8aVXTrjpmDrNHWA+pu/mEpWedzHB7TRzTUH+9i8wC+z6ni3xHt8zT+E7OvzTdpHddf4zBj9Q3gbUrSx1yT3c96NtDKjBwwc3cfhUt+3OWEyRjq5lo2cRwXbTodv+7p8QcSPP1Uqaf/ik+dSVUKRJHXHatBCxmPDhgmHMLVhZjYXENGJJAHM4BYUm65msmje7stcCfnuz7lcwAuAOV6gcASna7rjiiaKtDnbXOFceFcgrVraYBeY3ggEEEHaMl7C9vFExguYLgskkk3lZWF5e4DEmio7z0lijqI/4juHZHN3wuSzxxDaebl1rS7JW1rtTIml7yAB/dANpSPfd9vnNB1Yxk3aeLvhQrdbnzO1pHV3DYOACjrzVbabp+gzBvMp6KANxOaEIQsxMIQhACEIUmKOmJRHHTPNMFxXOXkSSDq7Afq58PVRiikqn7qLvUyWxN23KRo3ddKSvH6B/uWzSi9ejZ0bD13j+lu/mVPva822ePWOLjg1u8/HFc/tE7pHF7zVzjUn+9i9BUyMoYBTRZnM9uvadOASDA6Z+8csQQl7gxoqSaALo12WMQxtjGzM7ztPiqfRS6dQdM8dZw6o+0b+Z9EypiyqPdM3j8zyHuoVEu0dkZBYCFlC10shCEIQsEJL0luPoyZYx1Di4D6SdvL0TqvD2g4HJLVVK2oj2Hfg8CpxyFhvC5pYbY+F4ew0I2bCNoKfLpvRk7atwcO005j5HFLl/3AY6yRCrMy0Zt4jePRUVmtDo3B7CQRkR/eIWBDPNQSGN4w4eYTj2NmbeM023vcFavhHEs/47uSWZYthFCN+BCa7m0iZLRklGP/0u5HZyVheN1xzdoUdscM/3VlTZkVUN9SkA6jT2PLsXY6p0fQlGHzvXPHxELwr+3XLLFjTXbvb7hVT4wVhybyF2zK0gpwNa8bTCvNntkkfYe5vI4eC3m+7R/Od5fCiug3FeDGdysZUuAua8j8kKsxDUclsntcj+29zuZJ8lpRRC4SXYk3oAuyQhAC9CM7lwkIAJXlC3Ng3rY2MBVumaMsVY2NxWhkRKkxRZACpPeSrOw3LLLjTUbvd7Dame77qjhyFXbXHP9k7S2ZUVWLui3ideweqrkqI4sBiVVXRcGT5hxDP+XwrO9bzZZ21dmey0Zn4HFQr40iZFVkfXf/pbzO/gky02h0ji95q47T/eAWtJUQULN1T4u1PqdT1ZJQNfM7akyWy3218zy95qTkNgG4K40auTpCJZB1AatB+ojby9UaP3AZKSSijMw3a74b6pzY0AUGQUaCgdI7fTdoB16yuTTADYavVFlCF6FJoQhCEIQhCEIWFlCELFEtX1o2H1fDRrsy3Jp5bj5JmWFRPTxzN2Xi/5opMeWG8Lls0TmEtcC0jMHAq0uvSCWGjSddm52Y5O+U5Xhd0cwo9tdxGDhyKU7y0YlZUx/wARvg4d23uWBLQ1FK7bhJI6s/yE42aOQXOTJd99wzYB2q77XYHu2HuW613XFLi5gr9wwPiM1zhzaGhFCNhwI7lPsl8TxdmQ03O6w81Yy1mSN2KhgI+aLhpyDewpin0Y+x/c4e4VdNcM7cmh36SPQ0UizaXn8SPvaaeR+VZRaUWc5lzebT7KJpbMnxadn83cjgpiepZnilx93TDOJ/8AST6Lx/8ADk/lv/pPwnFl92c/it78PVe/8Wg/ms/qCibEpTlL/wCVIVsmrfFJrLumOUT/AOkj1UqK4J3ZtDf1Ee1UyPvuzj8Vvdj6KLLpRZxkXO5NPuu/pFDHi+S/8jyxXDVznJviotn0X+9/c0e5VtZLriixawV+44nxOSobTpgfw4u959h8qmtd8Ty9qQ03N6o8lYJ7Ppv2mXnj7uVZbPJ9xw+cE53hfcMOBdV32txPfu70q3ppBLNVo6jNzczzd7BU7G1NAKk7BiT3K9u7RiWShk/ht8XHu2d6ofWVdYdmMXDq8ypCOOLFypIYnPIa0FxOQGJTbcujQbR81C7YzMDnvKubvu2OEUY2m8nFx5lTloUdlMi6UmJ5D5xVMtQXYNwCwFlCFsJZCEIQhCEIQhCEIQhCEIQhCELBKEIRRRrLa2yF4b9Dyx1cMQATThiFi1W+OOuu8Nox8hr9rKa57qhCEWy745RSRgdx2jkc1RWvRFpxieW8HYjxzTIx4OIOeK8T2ljGue5wDWgucdwAqSlpqSGb72g9eqm2Rzcike0aNWhuTQ4fkPsaKDLYZW9qN4/yldKa4HI8VoZbGGR0Q7TWted1HFwGO/qlZ77FhP2uI5+KubVOGYXMyKZinNYqupua3aB5Lz0bNzfAKg2Gf8/+vup/V9XP2XL2iuVTyUmKwyu7Mbz/AJSukBjdgHcAtD7fE2RsJe0SOa54ZXEtbm6mwcSpNsNur+4f7XDVnQJMg0btD/pDR+c+wqreyaItGMkhdwb1R45qf/8AYrNq6/SEioAAZIXGrS4FrA3Wc0tDnawFKAmtAthv2CpaHlxArRjHvr1Q6jdRp13apDtVtTQ1pROR2VTszF/aq3VDypNju+OIUjYBx2nmc1LoqmPSCB1KdKSXFmr0E+sC0NLqs6PWaBrt6xAGOa2OvqEa9S+kZ1SeiloXa2rqsdqUkdrYUZU1Wg1oaLmi4Kkm/NWaFUtv6zktAkqXgEUa8511QSB1XEtcA00JIIAqt133pHOXNZrgs1S4SRSxEa1dXCVrScjkpLisEIQhCEIQhCEIQhCEIQhCEIQhCFUaQ3e6eHUa1jnVDh0jiGgjImjXa1M9Uih4Zq3XlCEpWvRd7i94MQe90pLqEawdHGGNNBlrsBpjTZVa7TotJL0jpGwa0rbW0nF3R9OGahaSyrtUtP29qo3JyQEISfJou9znO1Yml0ZaNWR4ERMRj1GsDAHMqSammfZJxWy26L63SsjZAxj7O6HEax1i2jepqdRodV1Qcd1cU1rIQhJ1p0YlfrAdDFrVIkYXF7P4Ij6Bo1W1ir1q1GfZBxUiK4JBMycNhj1NQdCwuMRoZNY9gdYa4c06uBFNtU0oCEJavK45ZXyupEDLEGa5Li+EhrgWs6o1mOJxNWnPOopDdom57i5zYW1D9WNtSyIvfAaMOqMCI31NBi/JOBQEIVTd106kRjcaNEz5WCNzmBrTKZGMwpgMAW5ZjJF5WWR80TmsiMbdYPLnua8hwLSA0RkOABri4ZnLNW6EISfNoo/UGqWvdrnqPkkDRGI3xRNEoBd1A4nLHWcMM1Iu+4p4jG3Xic2J752uxa50j4XRlpaAQ1ms9zqgk0oKYVLQUIQlu1XHIWRNZqa7dbWn13te1z3NfI5jWij6kdlxAy5Lw+7LSx0r4BCwuqGt6WQsJdIXumNYyI5KEgAAiriScKJnCEISrZ9H5RRtImMdJZ5XgPdI5rrO9rmhrixuuH6jCSdUgl+Dqq8uqyOja4vIMkjy95FaVOAArsDQ1vcpwQEIWUIQhCEIQhCEIQhC/9k='))],
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              'Recently Viewed stores',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
            ),
            SizedBox(
              height: 20,
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  UserCard(
                      MediaQuery.of(context).size.height * 0.25,
                      MediaQuery.of(context).size.width * 0.40,
                      Column(
                        children: [
                          Image.asset('assets/tws.jpg'),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            'True Wireless',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          )
                        ],
                      )),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.25,
                      MediaQuery.of(context).size.width * 0.40,
                      Column(
                        children: [
                          Image.asset('assets/smw.png'),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            'Smart Watches',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          )
                        ],
                      )),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.25,
                      MediaQuery.of(context).size.width * 0.40,
                      Column(
                        children: [
                          Image.asset('assets/atomic.png'),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            'Books',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          )
                        ],
                      )),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.25,
                      MediaQuery.of(context).size.width * 0.40,
                      Column(
                        children: [
                          Image.asset('assets/trouser.jpg'),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            'Mens trousers',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          )
                        ],
                      ))
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
