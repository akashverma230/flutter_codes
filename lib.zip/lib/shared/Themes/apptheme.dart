import 'package:flutter/material.dart';

class AppTheme {
    AppTheme._();
  static final ThemeData lighttheme = ThemeData(
      scaffoldBackgroundColor: Colors.white,
      appBarTheme: const AppBarTheme(backgroundColor: Colors.white),
      navigationBarTheme: const NavigationBarThemeData(backgroundColor: Colors.white),
      textTheme: const TextTheme(titleSmall: TextStyle(color: Colors.black)));
  static final ThemeData darktheme = ThemeData(
      scaffoldBackgroundColor: Colors.black,
      appBarTheme: const AppBarTheme(backgroundColor: Colors.black),
      textTheme: const TextTheme(titleSmall: TextStyle(color: Colors.white)));
}
