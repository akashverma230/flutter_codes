import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);
  static String verify = '';

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  var phone = '';
  var cc = '+91';
  bool dirty = false;
  bool val = false;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          leading: Icon(Icons.close),
          backgroundColor: Colors.blue,
          title: Container(
            height: 40,
            child: Image.asset('assets/flipkart-Logo.png')),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 9,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Login for better experience",
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Text("Enter your phone number to continue"),
                      SizedBox(
                        height: 15,
                      ),
                      TextFormField(
                        keyboardType: TextInputType.phone,
                        onChanged: (value) {
                          phone = value;
                        },
                        decoration: InputDecoration(
                            labelText: "Phone Number",
                            labelStyle: TextStyle(
                              color: Colors.blue[900],
                            ),
                            border: OutlineInputBorder()),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Row(
                        children: [
                          Checkbox(
                              value: val,
                              onChanged: (value) {
                                setState(() {
                                  val = true;

                                  dirty = true;
                                  //value = true;
                                });
                              }),
                          Expanded(
                            flex: 2,
                            child: Text(
                                "By continuing, you agree to Flipkarts terms and conditions"),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Divider(thickness: 1),
                      Center(child: Text('or')),
                      Center(
                        child: Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20)),
                            child: ElevatedButton(
                              style: ButtonStyle(
                                  backgroundColor:
                                      MaterialStatePropertyAll(Colors.red)),
                              onPressed: () {},
                              child: Text(
                                'signin with google',
                                style: TextStyle(color: Colors.white),
                              ),
                            )),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width,
                  height: 50,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 8, right: 8),
                    child: MaterialButton(
                      onPressed: () async {
                        await FirebaseAuth.instance.verifyPhoneNumber(
                            phoneNumber: '${cc + phone}',
                            verificationCompleted:
                                (PhoneAuthCredential credential) {},
                            verificationFailed: (FirebaseException e) {},
                            codeSent: (verificationId, forceResendingToken) {
                              Login.verify = verificationId;
                              Navigator.pushNamed(context, '/otp');
                            },
                            codeAutoRetrievalTimeout: (verificationId) {});
                        //Navigator.of(context).pushNamed("/home");
                      },
                      color: (dirty) ? Colors.orange : Colors.grey,
                      child: Text(
                        "CONTINUE",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
