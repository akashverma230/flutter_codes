import 'dart:ui';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:wordnik/utils/apiclient.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  TextEditingController tc = TextEditingController();
  ApiClient _client = ApiClient();
  List<dynamic> list = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  _callapi() async {
    final List list1 = await _client.getdata((tc.text).toLowerCase());
    setState(() {
      list = list1;
    });
    print('listdata is');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(
        leading: IconButton(onPressed: (){}, icon: Icon(Icons.menu)),
        actions: [
          IconButton(onPressed: (){}, icon: Icon(Icons.mic))
        ],
        backgroundColor: Colors.lightBlue,
        centerTitle: true,
        title: Text('Dictionary'),
      ),
      body: Container(
         decoration: BoxDecoration(
          image: DecorationImage(image: AssetImage('images/register.png',),fit: BoxFit.fill)
        //gradient: LinearGradient(
        //        colors: [Colors.blue, Colors.yellow,Colors.red],
        //       begin: Alignment.centerLeft,
        //        end: Alignment.centerRight,
        //   ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 30,),
            TextField(

              decoration: InputDecoration(border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),fillColor: Colors.white38,filled: true),
              style: TextStyle(fontSize: 25,fontStyle: FontStyle.normal,fontWeight: FontWeight.bold),
              controller: tc,
            ),
            SizedBox(
              height: 20,
            ),
            ElevatedButton(
               style: ButtonStyle(
      backgroundColor: MaterialStateProperty.all(Colors.red),
    ),
                onPressed: () {
                  _callapi();
                },
                child: Text('Search')),
                SizedBox(height: 50,),
           // Text(list[0]["meanings"]["definitions"]["definition"])
            Expanded(
              child: Container(
                decoration: BoxDecoration(border: Border.all(color: Colors.red),color: Colors.white,borderRadius: BorderRadius.all(Radius.circular(50)),
                boxShadow: [BoxShadow(blurRadius: 15)]
                ),
                padding: EdgeInsets.all(10),
                child: ListView.builder(
                  
                    itemCount: list.length,
                    itemBuilder: (context, index) {
                      return Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Center(
                            child: Text(list[0]["meanings"][0]["definitions"][0]
                                            ["definition"],style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
                          ),
                          SizedBox(height: 20,),
                          Center(
                            child: Text(list[0]["meanings"][0]["definitions"][2]
                                              ["definition"],style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
                          ),
                          SizedBox(height: 20,),
                        Text('phonetic :'+list[0]["phonetic"],style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold))
                        ],
                      );
                    }),
              ),
            ),

            // FutureBuilder(
            //     future: _callapi(),
            //     builder: (context, snapshot) {
            //       if (snapshot.hasData) {
            //         return CircularProgressIndicator();
            //       } else if (snapshot.hasError) {
            //         return Text('Something Went Wrong');
            //       } else {
            //         return Text(snapshot.data!["text"]);
            //       }
            //     })
          ],
        ),
      ),
    );
  }
}
