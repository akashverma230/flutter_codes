import 'package:connectivity_plus/connectivity_plus.dart';

Stream<ConnectivityResult> checkConnectivity() {
  Stream<ConnectivityResult> sub = Connectivity().onConnectivityChanged;
  return sub;
}