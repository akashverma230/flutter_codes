import 'dart:convert';

import 'package:dio/dio.dart';

class ApiClient {
  Dio _dio = Dio();
  Future<List<dynamic>> getdata(String word) async {
    String URL =
        'https://api.dictionaryapi.dev/api/v2/entries/en/$word';

    Response res = await _dio.get(URL);
    print(res.data);
    //var body=jsonDecode(res.data);
    //print(body);
    return res.data;
  }
}
