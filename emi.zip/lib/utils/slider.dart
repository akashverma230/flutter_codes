import 'package:flutter/material.dart';

class Slider2 extends StatefulWidget {
  const Slider2({Key? key}) : super(key: key);

  @override
  State<Slider2> createState() => _Slider2State();
}

class _Slider2State extends State<Slider2> {
  double amount = 100;
  @override
  Widget build(BuildContext context) {
    return Container(
        color: Colors.purple.shade100,
        margin: EdgeInsets.all(10),
        child: Column(
          children: [
            Text('Enter Principle Amount'),
            Text(
              amount.toStringAsFixed(2),
              style: TextStyle(fontSize: 20, color: Colors.black),
            ),
            Slider(
                activeColor: Colors.red,
                inactiveColor: Colors.white,
                max: 10000000,
                min: 100,
                value: amount,
                onChanged: (double value) {
                  setState(() {
                    amount = value;
                  });
                })
          ],
        ));
  }
}
