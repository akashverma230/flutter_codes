import 'package:flutter/material.dart';

class Bar extends StatelessWidget {
  const Bar({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Color.fromARGB(255, 50, 6, 128),
      centerTitle: true,
      title: Text('BMI CALCULATOR'),
      elevation: 10,
    );
      
    
  }
}