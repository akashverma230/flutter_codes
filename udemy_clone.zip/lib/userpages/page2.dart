import 'package:flutter/material.dart';

class Page2 extends StatelessWidget {
  const Page2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
         mainAxisAlignment: MainAxisAlignment.center,
        // crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: Image.network(
                'https://icon-library.com/images/play_2-512.png'),
          ),
          SizedBox(
            height: 40,
          ),
          Center(
            child: Text(
              'Learn from the Best',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Text('Approachable expert-instructors,'),
          Text('vetted by 35 million learners')
        ],
      ),
    );
  }
}
