import 'package:emi_app/Screens/calculate.dart';
import 'package:emi_app/Screens/result.dart';
import 'package:emi_app/utils/interest.dart';
import 'package:emi_app/utils/slider.dart';
import 'package:flutter/material.dart';

class Emi extends StatefulWidget {
  const Emi({Key? key}) : super(key: key);

  @override
  State<Emi> createState() => _EmiState();
}

class _EmiState extends State<Emi> {
  double amount = 100;
  int rate = 1;
  int tenure = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: Text('EMI Calculator'),
        elevation: 10,
        backgroundColor: Colors.purple,
      ),
      body: Column(
        children: [
          Expanded(flex: 1, child: Slider2()),
          Expanded(flex: 1, child: Card1('Interest Rate')),
          Expanded(flex: 1, child: Card1('Tenure(in years)')),
          RaisedButton(
              color: Colors.purple,
              child: Text('Calculate'),
              onPressed: () {
                Calculate calc = Calculate(P: amount, R: rate, n: tenure);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => Result(
                              emiresult: calc.getresult(),
                            )));
              })
        ],
      ),
    );
  }
}
