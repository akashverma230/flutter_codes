import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:news_api/api/apiclient.dart';
import 'package:news_api/pages/second.dart';

class FirstPage extends StatefulWidget {
  const FirstPage({Key? key}) : super(key: key);

  @override
  State<FirstPage> createState() => _FirstPageState();
}

class _FirstPageState extends State<FirstPage> {
  ApiClient client = ApiClient();
  List arr = [];
  _callapi() async {
    arr = await client.getdata();
  }

  @override
  void initState() {
    _callapi();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(
          'HEADLINES',
          style: GoogleFonts.notoSans(),
        ),
        centerTitle: true,
      ),
      body: FutureBuilder(
          future: client.getdata(),
          builder: (context, AsyncSnapshot<dynamic> snapshot) {
            if (snapshot.connectionState==ConnectionState.done) {
              return ListView.builder(
                itemBuilder: (context, index) => GestureDetector(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => SecondPage(arr, index)));
                      },
                      child: Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        margin: EdgeInsets.fromLTRB(10, 5, 10, 20),
                        elevation: 10,
                        child: Stack(
                          children: [
                            Image(
                              fit: BoxFit.fill,
                              image: NetworkImage(
                                  snapshot.data![index]["urlToImage"]),
                              colorBlendMode: BlendMode.softLight,
                              color: Colors.black.withOpacity(1.0),
                            ),
                            Positioned(
                                bottom: 30,
                                child: Container(
                                  height: 50,
                                  width: 300,
                                  child: Text(
                                    snapshot.data![index]["description"],
                                    style: GoogleFonts.openSans(
                                        color: Colors.white, fontSize: 20),
                                  ),
                                )),
                                Positioned(
                                  bottom: 0,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(snapshot.data![index]["source"]["name"],style:GoogleFonts.openSans(
                                          color: Colors.white, fontSize: 15) ,),
                                          SizedBox(width: 15,),
                                      Text(snapshot.data[index]["publishedAt"],style: GoogleFonts.openSans(
                                          color: Colors.white, fontSize: 15),)
                                    ],
                                  ),
                                )
                          ],
                        ),
                      ),
                    ));

            }
         else{
                        return Center(child: CircularProgressIndicator());
         }
            
          }),
    );
  }
}
