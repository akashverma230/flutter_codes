import 'package:flutter/material.dart';

class Page1 extends StatelessWidget {
  const Page1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Image.network(
                'https://cdn.iconscout.com/icon/premium/png-256-thumb/video-course-2-536962.png'),
          ),
          SizedBox(
            height: 40,
          ),
          Center(
            child: Text(
              'Take Video Courses',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Text('From cooking to coding'),
          Text('and everything in between')
        ],
      ),
    );
  }
}
