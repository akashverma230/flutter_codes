import 'package:flutter/material.dart';
import 'package:wordnik/pages/homepage.dart';


void main() {
  runApp(MaterialApp(
    home: HomePage(),
  ));
}
