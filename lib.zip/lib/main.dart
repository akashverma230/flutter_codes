import 'package:firebase_core/firebase_core.dart';
import 'package:flipkart/featured/navbar.dart';
import 'package:flipkart/featured/otp.dart';
import 'package:flipkart/splashscreen.dart';
import 'package:flutter/material.dart';

import 'featured/language.dart';
import 'featured/login.dart';
import 'pages/homepage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
   // home: NavBar(),
    routes: {
      '/': (context) => SplashScreen(),
      "/languagePage": (context) => Language(),
      "/login": (context) => Login(),
      "/navbar":(context) => NavBar(),
      "/home": (context) => HomePage(),
      "/otp" :(context) => Otp()
    },
  ));
}
