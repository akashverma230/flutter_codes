enum languageTitleEnum {
  Hindi,
  English,
  Punjabi,
  Assamese,
  telugu,
  Tamil,
  Bengali,
  Marathi,
  kannada,
  Odia,
  Gujrati,
  Malyalam,
}
