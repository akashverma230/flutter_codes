import 'package:flipkart/shared/cards/usercard.dart';
import 'package:flipkart/shared/cards/avatar.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        //   margin: EdgeInsets.all(5),
        //     height: 5,
        //     width: 10,
        //     child: Row(children: [
        //       Text('Search for products'),
        //       IconButton(onPressed: (){}, icon: Icon(Icons.mic)),
        //       IconButton(onPressed: (){},icon: Icon(Icons.camera),)
        //     ]),
        //   )],

        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                //IconButton(onPressed: () {}, icon: Icon(Icons.card_travel)),
                //SizedBox(width: 5,),
                Container(
                    margin: EdgeInsets.all(5),
                    width: 40,
                    child: Image.asset('assets/flipkart_icon.png')),
                SizedBox(
                  width: 10,
                ),
                const Text(
                  'Flipkart',
                  style: TextStyle(
                      color: Colors.blue,
                      fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.bold,
                      fontSize: 30),
                ),
                //IconButton(onPressed: (){}, icon: Image.asset('flipkart_icon.png'),)
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              margin: EdgeInsets.all(5),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5), border: Border.all()),
              child: Row(
                children: [
                  SizedBox(
                    width: 80,
                  ),
                  Text(
                    'Search for products',
                    style: TextStyle(color: Colors.grey, fontSize: 20),
                  ),
                  SizedBox(
                    width: 27,
                  ),
                  IconButton(
                      onPressed: () {},
                      icon: Icon(
                        Icons.mic,
                        color: Colors.grey,
                      )),
                  IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.camera_alt,
                      color: Colors.grey,
                    ),
                  )
                ],
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  UserCard(
                      MediaQuery.of(context).size.height * 0.20,
                      MediaQuery.of(context).size.width * 1,
                      Image.asset('assets/boat.jpg')),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.20,
                      MediaQuery.of(context).size.width * 1,
                      Image.asset('assets/AC.jpg')),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.20,
                      MediaQuery.of(context).size.width * 1,
                      Image.asset('assets/fashion.jpg')),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.20,
                      MediaQuery.of(context).size.width * 1,
                      Image.asset('assets/fireboltt.jpg')),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.20,
                      MediaQuery.of(context).size.width * 1,
                      Image.asset('assets/oneplus.jpg')),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.20,
                      MediaQuery.of(context).size.width * 1,
                      Image.asset('assets/asus.jpg'))
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
            SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [Avatar('Supercoin',Image.asset('assets/supercoin.jpg')),
                Avatar('coupons',Image.asset('assets/coupons.png')),
                Avatar('Credit',Image.asset('assets/credit.jpg')),
                Avatar('Group Buy',Image.asset('assets/grp.jpg')),
                Avatar('Whats New',Image.asset('assets/new.jpg'))],
            
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Text(
              'Recently Viewed stores',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
            ),
            SizedBox(
              height: 20,
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  UserCard(
                      MediaQuery.of(context).size.height * 0.25,
                      MediaQuery.of(context).size.width * 0.40,
                      Column(
                        children: [
                          Image.asset('assets/tws.jpg'),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            'True Wireless',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          )
                        ],
                      )),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.25,
                      MediaQuery.of(context).size.width * 0.40,
                      Column(
                        children: [
                          Image.asset('assets/smw.png'),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            'Smart Watches',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          )
                        ],
                      )),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.25,
                      MediaQuery.of(context).size.width * 0.40,
                      Column(
                        children: [
                          Image.asset('assets/atomic.png'),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            'Books',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          )
                        ],
                      )),
                  UserCard(
                      MediaQuery.of(context).size.height * 0.25,
                      MediaQuery.of(context).size.width * 0.40,
                      Column(
                        children: [
                          Image.asset('assets/trouser.jpg'),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            'Mens trousers',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          )
                        ],
                      ))
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
