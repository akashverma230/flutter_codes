// import 'package:flutter/material.dart';
// import 'package:wordnik/utils/apiclient.dart';

// class NewPage extends StatefulWidget {
//   const NewPage({Key? key}) : super(key: key);

//   @override
//   State<NewPage> createState() => _NewPageState();
// }

// class _NewPageState extends State<NewPage> {
//   ApiClient _client = ApiClient.getInstance();
//   List<dynamic> news = [];
//   // _getdata() {
//   //   Future<Response> res = _client.getdata(
//   //       'https://newsapi.org/v2/top-headlines?country=us&apiKey=11f0dc28d8874be0bb82287cbcf26121');
//   //   return res;
//   // }
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     // _callNews();
//   }

//   _callNews() async {
//     news = await _client.getdata();
//     setState(() {});
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: AppBar(title: Text('News App')),
//         //body: ,
//         body: FutureBuilder(
//           future: _client.getdata(),
//           builder: (ctx, AsyncSnapshot<List<dynamic>> snapshot) {
//             if (snapshot.hasError) {
//               return Center(child: Text('Something Went Wrong...'));
//             } else if (!snapshot.hasData) {
//               return Center(child: CircularProgressIndicator());
//             } else {
//               return ListView.builder(
//                   itemCount: snapshot.data?.length,
//                   itemBuilder: (_, int index) {
//                     return ListTile(
//                       leading: Image.network((snapshot.data![index]
//                               ['urlToImage']) ??
//                           "http://cdn.onlinewebfonts.com/svg/img_98811.png"),
//                       title: Text((snapshot.data![index]['content']) ?? ""),
//                       subtitle:
//                           Text((snapshot.data![index]['description']) ?? ""),
//                     );
//                   });
//             }
//           },
//         ));
//   }
// }
