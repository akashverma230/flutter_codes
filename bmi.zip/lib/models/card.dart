import 'package:flutter/material.dart';

class CardModel {
  IconData icon;
  String name;
  CardModel(this.icon, this.name);
  
  }

