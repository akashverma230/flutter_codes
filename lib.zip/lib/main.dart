import 'package:flipkart/featured/navbar.dart';
import 'package:flutter/material.dart';

import 'pages/homepage.dart';

void main(){
  runApp(MaterialApp(
    home: NavBar()
  ));
}