import 'package:flames1/pages/splash.dart';
import 'package:flutter/material.dart';
import 'flamepage.dart';

void main() {
  runApp(MaterialApp(
    title: 'Flame App',
    home: SplashDemo(),
    darkTheme: ThemeData.light(),
  ));
}
