import 'dart:convert';

import 'package:api_cache_manager/models/cache_db_model.dart';
import 'package:api_cache_manager/utils/cache_manager.dart';
import 'package:dio/dio.dart';

class ApiClient {
  Dio _dio = Dio();
  getdata() async {
    String Api =
        'https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey=148c7f49fa3546918ee1a39f82384ce3';
    Response res = await _dio.get(Api);
    var isCacheexist = await APICacheManager().isAPICacheKeyExist("articles");
    if (!isCacheexist) {
      return res.data["articles"];
    } else {
      APICacheDBModel cacheDBModel =
          new APICacheDBModel(key: "articles", syncData: res.data);
      await APICacheManager().addCacheData(cacheDBModel);
      var cachedata = await APICacheManager().getCacheData("articles");
      return json.decode(cachedata.syncData);
    }
  }
}
