import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class flip extends StatefulWidget {
  const flip({super.key});

  @override
  State<flip> createState() => _flipState();
}

class _flipState extends State<flip> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: Image.asset(
              'assets/cart.png',
              height: 220,
            ),
          ),
          Center(
              child: Text(
            'Missing Cart items?',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          )),
          SizedBox(
            height: 20,
          ),
          Text(
            "Login to see the items you added previously",
            style: TextStyle(
              color: Colors.black54,
            ),
          ),
          SizedBox(
            height: 30,
          ),
          Center(
            child: Container(
              height: MediaQuery.of(context).size.height * 0.05,
              width: MediaQuery.of(context).size.width * 0.40,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context, rootNavigator: true)
                      .pushReplacementNamed(
                    "/login",
                  );
                },
                child: Text(
                  'Login',
                  style: TextStyle(
                    fontSize: 15,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(
            height: 15,
          ),
          Center(
            child: Container(
              height: MediaQuery.of(context).size.height * 0.05,
              child: InkWell(
                onTap: () {
                  Navigator.of(context, rootNavigator: true).pushNamed("/home");
                },
                child: Text(
                  "Continue Shopping",
                  style: TextStyle(
                    color: Colors.blue,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
