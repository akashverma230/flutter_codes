import 'package:bmi/models/card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Card1 extends StatelessWidget {
  const Card1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        children: [
          Column(
            children: [
              Card(
                child: Icon(Icons.male),
              ),
              Text('MALE')
            ],
          ),
          Column(
            children: [
              Card(
                child: Icon(Icons.female),
              ),
              Text('FEMALE')
            ],
          )
        ],
      ),
    );
  }
}
