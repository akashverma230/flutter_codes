import 'package:flutter/material.dart';

class Notify extends StatefulWidget {
  const Notify({super.key});

  @override
  State<Notify> createState() => _NotifyState();
}

class _NotifyState extends State<Notify> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: Text('Notifications'),),
        body: Column(
          children: [
            SizedBox(height: MediaQuery.of(context).size.height*0.10),
            Center(child: Text('you are missing out',style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold,color: Colors.black54),)),
            SizedBox(height: MediaQuery.of(context).size.height*0.03,),
            Center(child: Text('Signin to view exclusive offers',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.black54),)),
            SizedBox(height: MediaQuery.of(context).size.height*0.03,),
            Container(
              height: MediaQuery.of(context).size.height*0.05,
              width: MediaQuery.of(context).size.width*0.40,
              child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context, rootNavigator: true).pushNamed( "/login");
                  },
                  child: Text('Sign in',style: TextStyle(fontSize: 20),)),
            )
          ],
        ),
      ),
    );
  }
}
