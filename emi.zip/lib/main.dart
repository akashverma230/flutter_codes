import 'package:emi_app/Screens/emi.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Emi(),
  ));
}
