import 'dart:async';

import 'package:flutter/material.dart';
import 'package:skill_risers/pages/userpageview.dart';

class UserSplash extends StatefulWidget {
  const UserSplash({Key? key}) : super(key: key);
  

  @override
  State<UserSplash> createState() => _UserSplashState();
}


class _UserSplashState extends State<UserSplash> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  
  }
  @override
  Widget build(BuildContext context) {
    Timer(
            Duration(seconds: 5),
                () =>
            Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (BuildContext context) => UserPageView())));

    return Scaffold(
      body: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(height: 180,),
            Center(child: Image.network('https://skillrisers.com/logo.png')),
            SizedBox(height: 30,),
            Center(
                child: Text(
              'Skill Risers',
              style: TextStyle(fontSize: 45, color: Colors.blue),
            )),
            Positioned(
              bottom: 1,

              child: CircularProgressIndicator())
          ],
        ),
      ),
    );
  }
}
