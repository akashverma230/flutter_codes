import 'package:flutter/material.dart';

class Page3 extends StatelessWidget {
  const Page3({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
         mainAxisAlignment: MainAxisAlignment.center,
        // crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: Image.network(
                'https://static.thenounproject.com/png/2797159-200.png'),
          ),
          SizedBox(
            height: 40,
          ),
          Center(
            child: Text(
              'Go at Your Own Pace',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Text('Lifetime access to purchsed courses'),
          Text('anytime,anywhere')
        ],
      ),
    );
  }
}
