import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class flip extends StatefulWidget {
  const flip({super.key});

  @override
  State<flip> createState() => _flipState();
}

class _flipState extends State<flip> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        //mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: Container(
              height: MediaQuery.of(context).size.height*0.3,
              width: MediaQuery.of(context).size.width*0.3,
              child: Image.asset('assets/cart.png')
              ),
          ),
          Center(child: Text('Your Cart is Empty',style: TextStyle(fontSize: 20),)),
          SizedBox(height: 10,),
          Center(
            child: Container(
              height: MediaQuery.of(context).size.height * 0.05,
              width: MediaQuery.of(context).size.width * 0.40,
              child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context, rootNavigator: true)
                        .pushReplacementNamed("/navbar");
                  },
                  child: Text(
                    'Shop now',
                    style: TextStyle(fontSize: 20),
                  )),
            ),
          )
        ],
      ),
    );
  }
}
