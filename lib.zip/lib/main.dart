import 'package:firebase_core/firebase_core.dart';
import 'package:flipkart/featured/navbar.dart';
import 'package:flipkart/featured/otp.dart';
import 'package:flipkart/pages/notification.dart';
import 'package:flipkart/shared/Themes/appstatenotifier.dart';
import 'package:flipkart/splashscreen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'featured/language.dart';
import 'featured/login.dart';
import 'pages/homepage.dart';
import 'shared/Themes/apptheme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(
    ChangeNotifierProvider<AppStateNotifier>(
       create: (context) => AppStateNotifier(),
      builder: (context, child) => MyApp()
   ) );
}
class MyApp extends StatelessWidget{
  Widget build(BuildContext context){
    return Consumer<AppStateNotifier>(
    builder: (context,appState,child){
      return MaterialApp(
          theme: ThemeData.light(),
          darkTheme: ThemeData.dark(),
          debugShowCheckedModeBanner: false,
         // themeMode: appState.isDark?ThemeMode.dark:ThemeMode.light,
          
          home: NavBar()
          // routes: {
          // '/': (context) => SplashScreen(),
          //   "/languagePage": (context) => Language(),
          //   "/login": (context) => Login(),
          //   "/navbar":(context) => NavBar(),
          //   "/home": (context) => HomePage(),
          //   "/otp" :(context) => Otp(),
          //   "/notification":(context) => Notify()
          //  },
 ); });

  
    }
  }
  
  

