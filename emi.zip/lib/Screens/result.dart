import 'package:flutter/material.dart';

class Result extends StatelessWidget {
  Result({this.emiresult});
  final emiresult;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('EMI Calculator'),
      ),
      body: Column(
        children: [Text('Your EMI Is....'), Text(emiresult)],
      ),
    );
  }
}
