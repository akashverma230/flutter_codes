import 'package:flutter/material.dart';

class Card1 extends StatelessWidget {
  Card1(this.e);
  String e;
  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.red.shade100,
      child: Column(
        children: [
          Text(e),
          TextField(
            decoration: InputDecoration(labelText: e),
          )
        ],
      ),
    );
  }
}
