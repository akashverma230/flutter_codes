import 'package:flutter/material.dart';
import 'package:skill_risers/pages/mainpage.dart';

class UserNavigationBar extends StatefulWidget {
  const UserNavigationBar({Key? key}) : super(key: key);

  @override
  State<UserNavigationBar> createState() => _UserNavigationBarState();
}

class _UserNavigationBarState extends State<UserNavigationBar> {
  int currentidx = 0;
  final Screens = [MainPage()];
  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      
      selectedItemColor: Colors.black,
      unselectedItemColor: Colors.grey,
      currentIndex: currentidx,
      onTap: (index) => setState(() {
        currentidx = index;
      }),
      
      items: [
        BottomNavigationBarItem(
          label: 'Featured',
          icon: Icon(Icons.star),
        ),
        BottomNavigationBarItem(
          label: 'Search',
          icon: Icon(Icons.search),
        ),
        BottomNavigationBarItem(
          label: 'My Learning',
          icon: Icon(Icons.video_settings_rounded),
        ),
        BottomNavigationBarItem(
          label: 'WishList',
          icon: Icon(Icons.favorite),
        ),
      ],
    );
  }
}
