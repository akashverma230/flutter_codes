import 'package:flutter/material.dart';
import '../utils/flameoperations.dart';
import '../widgets/customtext.dart';
import '../widgets/options.dart';

class FlamePage extends StatefulWidget {
  const FlamePage({Key? key}) : super(key: key);

  @override
  State<FlamePage> createState() => _FlamePageState();
}

class _FlamePageState extends State<FlamePage> {
  
  
  String relationShip = "";
  _compute() {
    FlameOperations opr = FlameOperations();
    int count = opr.getCount(tc1.text, tc2.text);
    print("Count is $count");
    relationShip = opr.getTheRelationShip(count);
    setState(() {});
    //opr.removeFlameChars(count);
  }

  TextEditingController tc1 = TextEditingController();
  TextEditingController tc2 = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          child: SingleChildScrollView(
            child: Column(
                    children: [
            CustomTextField('Male', Icons.male, tc1),
            CustomTextField('Female', Icons.female, tc2),
            Container(
              margin: EdgeInsets.only(right: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  ElevatedButton(
                      style: ButtonStyle(
                          backgroundColor:
                              MaterialStateProperty.all(Colors.deepOrange)),
                      onPressed: () {
                        _compute();
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          'Compute',
                          style: TextStyle(fontSize: 20),
                        ),
                      ))
                ],
              ),
            ),
            FlameOptions(),
            Text("Your RelationShip is $relationShip")
                    ],
                  ),
          )),
      appBar: AppBar(
          backgroundColor: Colors.teal,
          centerTitle: true,
          title: Text('Flame App')),
    );
  }
}
