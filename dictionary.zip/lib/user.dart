class User {
  late String image;
  late String meanings;
  User() {}
  Map<String, dynamic> toJSON() {
    return {"image": image, "meanings": meanings};
  }
}
