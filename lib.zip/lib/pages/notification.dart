import 'package:flutter/material.dart';

class Notify extends StatefulWidget {
  @override
  State<Notify> createState() => _NotifyState();
}

class _NotifyState extends State<Notify> {
  @override
  Widget build(BuildContext context) {
    // TODO(username): implement build
    return Container(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Notifications'),
        ),
        //backgroundColor: Colors.white,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              child: Image.asset(
                'assets/notify.png',
                height: 50,
                width: 500,
              ),
              height: 100,
            ),
            const Center(
              child: Text(
                "You're missing out",
                style: TextStyle(fontWeight: FontWeight.w500, fontSize: 20),
              ),
            ),
            const Text("Sign in to view personlished notifications and offers"),
            ElevatedButton(
                onPressed: () {
                  Navigator.of(
                    context,
                    rootNavigator: true,
                  ).pushNamed("/login");
                },
                child: Text('Sign in'))
          ],
        ),
      ),
    );
  }
}
