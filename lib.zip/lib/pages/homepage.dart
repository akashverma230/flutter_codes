import 'package:carousel_slider/carousel_slider.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flipkart/main.dart';
import 'package:flipkart/shared/Themes/appstatenotifier.dart';
import 'package:flipkart/shared/cards/usercard.dart';
import 'package:flipkart/shared/cards/avatar.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../shared/Themes/apptheme.dart';
import '../shared/cards/container2.dart';
import '../shared/cards/list.dart';
import '../shared/cards/usercontainer.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _items = [
    'boat.jpg',
    'AC.jpg',
    'fashion.jpg',
    'fireboltt.jpg',
    'oneplus.jpg',
    'asus.jpg'
  ];
  int current = 0;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,

          //leading: Icon(Icons.menu),
          //actions: [IconButton(onPressed: (){}, icon: Icon(Icons.shopping_cart))],
          title: Container(
            height: 100,
            child: Expanded(
              flex: 3,
              child: Row(
                children: [Image.asset('assets/Flipkart-logo.png')],
              ),
            ),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(60),
            child: Row(
              children: [
                Switch(
                    value: Provider.of<AppStateNotifier>(context).isDark,
                    onChanged: (value) {
                      setState(() {
                        Provider.of<AppStateNotifier>(context)
                            .updateTheme(value);
                      });
                    }),
                Expanded(
                  child: Container(
                      height: MediaQuery.of(context).size.height * 0.05,
                      margin: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                          color: Colors.grey.shade50,
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(
                              width: 0.2, color: Colors.grey.shade400)),
                      child: TextFormField(
                        decoration: InputDecoration(
                            //contentPadding: EdgeInsets.all(5),
                            isDense: true,
                            hintText: 'Search for Products and More...',
                            suffixIcon: Icon(Icons.camera_alt),
                            prefixIcon: Icon(Icons.search)),
                      )),
                ),
              ],
            ),
          ),
        ),
        //  drawer: Drawer(
        //     child: Column(
        //       children: [
        //         UserAccountsDrawerHeader(accountName: Text('Akash'), accountEmail: Text('akash@flipkart.com'),currentAccountPicture: CircleAvatar(backgroundImage: AssetImage('assets/fashion.jpg'),)),

        //     ],
        //   ),
        // ),
        //   margin: EdgeInsets.all(5),
        //     height: 5,
        //     width: 10,
        //     child: Row(children: [
        //       Text('Search for products'),
        //       IconButton(onPressed: (){}, icon: Icon(Icons.mic)),
        //       IconButton(onPressed: (){},icon: Icon(Icons.camera),)
        //     ]),
        //   )],

        body: ListView(children: [
          //   SizedBox(
          //   height: 10,
          // ),

          SizedBox(
            height: 10,
          ),
          // SingleChildScrollView(
          //   scrollDirection: Axis.horizontal,
          //   child: Row(
          //     children: [
          //       UserCard(
          //           MediaQuery.of(context).size.height * 0.20,
          //           MediaQuery.of(context).size.width * 1,
          //           Image.asset('assets/boat.jpg',fit: BoxFit.fill,)),
          //       UserCard(
          //           MediaQuery.of(context).size.height * 0.20,
          //           MediaQuery.of(context).size.width * 1,
          //           Image.asset('assets/AC.jpg',fit: BoxFit.fill,)),
          //       UserCard(
          //           MediaQuery.of(context).size.height * 0.20,
          //           MediaQuery.of(context).size.width * 1,
          //           Image.asset('assets/fashion.jpg',fit: BoxFit.fill,)),
          //       UserCard(
          //           MediaQuery.of(context).size.height * 0.20,
          //           MediaQuery.of(context).size.width * 1,
          //           Image.asset('assets/fireboltt.jpg',fit: BoxFit.fill,)),
          //       UserCard(
          //           MediaQuery.of(context).size.height * 0.20,
          //           MediaQuery.of(context).size.width * 1,
          //           Image.asset('assets/oneplus.jpg',fit: BoxFit.fill,)),
          //       UserCard(
          //           MediaQuery.of(context).size.height * 0.20,
          //           MediaQuery.of(context).size.width * 1,
          //           Image.asset('assets/asus.jpg',fit: BoxFit.fill,))
          //     ],
          //   ),
          // ),
          Stack(children: [
            CarouselSlider.builder(
              itemCount: _items.length,
              options: CarouselOptions(
                  onPageChanged: (index, reason) {
                    current = index;
                  },
                  enlargeCenterPage: true,
                  autoPlay: true,
                  initialPage: 0,
                  enableInfiniteScroll: true,
                  height: MediaQuery.of(context).size.height * 0.20),
              itemBuilder: (context, index, realIndex) {
                current = index;
                final img = _items[index];
                return UserCard(
                    MediaQuery.of(context).size.height * 0.20,
                    MediaQuery.of(context).size.width * 1,
                    Image.asset(
                      'assets/${img}',
                      fit: BoxFit.fill,
                    ));
              },
            ),
            Positioned(
              bottom: 0,
              left: MediaQuery.of(context).size.width * 0.4,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: _items.map((url) {
                  int index = _items.indexOf(url);
                  return Container(
                    width: 8,
                    height: 8,
                    margin: EdgeInsets.symmetric(
                      vertical: 10,
                      horizontal: 3,
                    ),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: current == index
                          ? Colors.white
                          : Colors.grey,
                    ),
                  );
                }).toList(),
              ),
            )
          ]),
          SizedBox(
            height: 20,
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Avatar('Supercoin', Image.asset('assets/supercoin.jpg')),
                Avatar('coupons', Image.asset('assets/coupons.png')),
                Avatar('Credit', Image.asset('assets/credit.jpg')),
                Avatar('Group Buy', Image.asset('assets/grp.jpg')),
                Avatar('Whats New', Image.asset('assets/new.jpg')),
                Avatar('Whats New', Image.asset('assets/new.jpg')),
              ],
            ),
          ),
          Container2(96, 96, 97, this.context),
          SizedBox(
            height: 20,
          ),
          Userlist('Recently viewed stores', this.context),
          SizedBox(
            height: 20,
          ),
          Userlist('Discounts For You', this.context),
          SizedBox(
            height: 20,
          ),
          Userlist('Sponsored', this.context),
          SizedBox(
            height: 20,
          ),
          Userlist('Shop Now', this.context),
          SizedBox(
            height: 20,
          ),
          UserContainer(75, 233, 167, context, 'Popular Pickup'),
          Divider(),
          Container2(254, 255, 254, context),
          Container2(254, 255, 254, context),
          UserContainer(40, 74, 124, context, 'Shop for a Cool Summer')
          // GridView(
          // gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          //   crossAxisCount: 2,
          // ),
          // children: [
          //   UserCard(
          //           MediaQuery.of(context).size.height * 0.25,
          //           MediaQuery.of(context).size.width * 0.40,
          //           Column(
          //             children: [
          //               Image.asset('assets/atomic.png'),
          //               SizedBox(
          //                 width: 5,
          //               ),
          //               Text(
          //                 'Books',
          //                 style: TextStyle(fontWeight: FontWeight.bold),
          //               )
          //             ],
          //           )),
          //           UserCard(
          //           MediaQuery.of(context).size.height * 0.25,
          //           MediaQuery.of(context).size.width * 0.40,
          //           Column(
          //             children: [
          //               Image.asset('assets/atomic.png'),
          //               SizedBox(
          //                 width: 5,
          //               ),
          //               Text(
          //                 'Books',
          //                 style: TextStyle(fontWeight: FontWeight.bold),
          //               )
          //             ],
          //           )),
          // ],
          //     ),
        ]),
      ),
    );
  }
}
