import 'dart:math';

import 'package:flutter/material.dart';

class Calculate {
  Calculate({required this.P, required this.R, required this.n});
  final double P;
  final int R;
  final int n;
  double _emiresult = 0;
  String getresult() {
    _emiresult = P * R * pow(1 + R, n) / (pow(1 + R, n) - 1);
    return _emiresult.toStringAsFixed(2);
  }
}
