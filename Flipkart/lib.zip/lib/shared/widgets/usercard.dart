import 'package:flutter/material.dart';

Widget UserCard(double h, double w, Widget wid,BuildContext context) {
  return Container(
    height: h,
    width: w,
    child: Card(
      color: Theme.of(context).cardColor,
      shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(5.0),
  ),
      elevation: 10,
      child: wid,
    ),
  );
}
