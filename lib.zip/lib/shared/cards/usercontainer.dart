import 'package:flutter/material.dart';

import 'usercard.dart';

Widget UserContainer(int a,int b,int c,BuildContext context,String s){
  return Container(
    color: Color.fromARGB(
      255, a, b, c),
    child: Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(s,style: Theme.of(context).textTheme.titleLarge),
        SizedBox(height: MediaQuery.of(context).size.height*0.03,),
        Row(
          children: [
            Expanded(
              child: UserCard(
                  MediaQuery.of(context).size.height*0.40,
                  MediaQuery.of(context).size.width *0.30,
                  Image.asset('assets/smw.png')),
            ),
            Expanded(
              child: UserCard(
                  MediaQuery.of(context).size.height*0.40 ,
                  MediaQuery.of(context).size.width*0.30 ,
                  Image.asset('assets/boat.jpg')),
            )
          ],
        ),
        Row(
          children: [
            Expanded(
              
              child: UserCard(
                  MediaQuery.of(context).size.height * 0.40,
                  MediaQuery.of(context).size.width * 0.30,
                  Image.asset('assets/smw.png')),
            ),
            Expanded(
              
              child: UserCard(
                  MediaQuery.of(context).size.height * 0.40,
                  MediaQuery.of(context).size.width * 0.30,
                  Image.asset('assets/boat.jpg')),
            )
          ],
        )
      ],
    ),
  );

}