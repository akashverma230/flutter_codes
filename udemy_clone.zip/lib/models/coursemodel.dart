class CourseModel {
  String? courseImage;
  String? trainer;
  String? title;
  CourseModel(this.courseImage, this.trainer, this.title);

}
