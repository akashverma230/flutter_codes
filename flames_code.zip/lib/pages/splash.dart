import 'dart:async';
import 'package:flames1/pages/flamepage.dart';
import 'package:flutter/material.dart';

class SplashDemo extends StatefulWidget {
  const SplashDemo({Key? key}) : super(key: key);

  @override
  State<SplashDemo> createState() => _SplashDemoState();
}

class _SplashDemoState extends State<SplashDemo> {
  @override
  void initState() {
    // Timer(
    //      Duration(seconds: 3),
    //     () =>Navigator.pushReplacement(
    //         context, MaterialPageRoute(builder: (context) =>  Name())));

    getDelay();
    // TODO: implement initState
    super.initState();
  }

  //

  getDelay() {
    Timer(
        Duration(seconds: 3),
        () => Navigator.pushReplacement(
            this.context,
            MaterialPageRoute(
              builder: (BuildContext context) => FlamePage(),
            )));
  }

  // @override
  // Widget build(BuildContext context) {
  //   Timer(
  //       Duration(seconds: 3),
  //       () => Navigator.of(context).push(
  //           MaterialPageRoute(builder: (BuildContext context) => Name())));
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [
        Text(
          'FLAMES',
          style: TextStyle(fontSize: 20, fontStyle: FontStyle.italic),
        ),
        Expanded(
          child: Image.network(
              'https://www.ubuy.co.in/productimg/?image=aHR0cHM6Ly9tLm1lZGlhLWFtYXpvbi5jb20vaW1hZ2VzL0kvNzFsVkFHYXFCdEwuX0FDX1NMMTAwMF8uanBn.jpg'),
        ),
        // LinearProgressIndicator(
        //   backgroundColor: Colors.grey,
        //   color: Colors.blue,
        //   minHeight: 5,
        // )
      ]),
    );
  }
}
