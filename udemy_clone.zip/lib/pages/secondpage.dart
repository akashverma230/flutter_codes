import 'package:flutter/material.dart';

class SecondPage extends StatefulWidget {
  int? index_key;
  List<dynamic> list = [];
   SecondPage(this.list, this.index_key);

  @override
  State<SecondPage> createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 40,),
              Card(child: Image.network(widget.list[widget.index_key!]["courseImage"]),elevation: 10),
             const SizedBox(
                height: 10,
              ),
              Text(widget.list[widget.index_key!]["title"],style: const TextStyle(fontSize:30),),
              const SizedBox(height: 10,),
              Text(widget.list[widget.index_key!]["subTitle"],style:const TextStyle(color:Colors.grey,),),
              const SizedBox(height: 10,),
              Text('created by'+' : '+ widget.list[widget.index_key!]["trainer"]["fullName"]),
              const SizedBox(height: 5,),
              Text('\$'+' '+(widget.list[widget.index_key!]['costPrice']).toString(),style: const TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
              const SizedBox(height: 20,),
              ElevatedButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.purple),
              ),
              onPressed: (){
              },
              child: const Text(
                'Buy Now',
                style: TextStyle(color: Colors.white),
              ),
            ),
              const SizedBox(height: 30,),
              const Text('Prerequisites :-',style: TextStyle(fontSize: 20),),
            Text((widget.list[widget.index_key!]["objectives"]).toString()),
            SizedBox(height: 30,),
            Text('No. of Lectures'+' '+(widget.list[widget.index_key!]["totalNumChapters"]).toString()),
             const SizedBox(
              height: 20,
             ),
               const Text('About Trainer'),
            const SizedBox(
              height: 20,
             ),
             CircleAvatar(backgroundImage: NetworkImage(widget.list[widget.index_key!]["trainer"]["photo"]),radius: 60,),
             const SizedBox(height:10),
             Text('Experience'+' '+widget.list[widget.index_key!]["trainer"]["developmentExperience"]),
             const SizedBox(height: 10,),
             Text(widget.list[widget.index_key!]["trainer"]["biography"])
          
          
          ],
          ),
        ),
      ),
    );
  }
}
