// TODO Implement this library.import 'package:flutter/material.dart';

import 'package:flutter/material.dart';

Widget Avatar(String name, Widget wid, BuildContext context) {
  return Container(
    margin: EdgeInsets.all(10),
    child: Column(
      children: [
        CircleAvatar(
          radius: 20,
          child: wid,
        ),
        Text(
          name,
          style: TextStyle(fontSize: 15, color: Theme.of(context).accentColor),
        )
      ],
    ),
  );
}
