import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

import '../shared/cards/avatar.dart';

class Category extends StatefulWidget {
  const Category({super.key});

  @override
  State<Category> createState() => _CategoryState();
}

class _CategoryState extends State<Category> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('All Categories'),
        actions: [Icon(Icons.search),
        Icon(Icons.mic)],

      ),
      body: Column(
        children: [
          SizedBox(height: 10,),
          Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Avatar('Supercoin',Image.asset('assets/supercoin.jpg')),
                Avatar('coupons',Image.asset('assets/coupons.png')),
                Avatar('Credit',Image.asset('assets/credit.jpg')),
                Avatar('Group Buy',Image.asset('assets/grp.jpg')),
                //Avatar('Whats New',Image.asset('assets/new.jpg')),
            ],
          ),
          SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              //Avatar('Supercoin',Image.asset('assets/supercoin.jpg')),
                Avatar('coupons',Image.asset('assets/coupons.png')),
                Avatar('Credit',Image.asset('assets/credit.jpg')),
                Avatar('Group Buy',Image.asset('assets/grp.jpg')),
                Avatar('Whats New',Image.asset('assets/new.jpg'))
            ],
          ),
          SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Avatar('Supercoin',Image.asset('assets/supercoin.jpg')),
                Avatar('coupons',Image.asset('assets/coupons.png')),
              //  Avatar('Credit',Image.asset('assets/credit.jpg')),
                Avatar('Group Buy',Image.asset('assets/grp.jpg')),
                Avatar('Whats New',Image.asset('assets/new.jpg'))
            ],
          ),
          SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
            Avatar('Supercoin',Image.asset('assets/supercoin.jpg')),
                Avatar('coupons',Image.asset('assets/coupons.png')),
                Avatar('Credit',Image.asset('assets/credit.jpg')),
               // Avatar('Group Buy',Image.asset('assets/grp.jpg')),
                Avatar('Whats New',Image.asset('assets/new.jpg'))
          ],)
        ],
      ),
    );
  }
}
