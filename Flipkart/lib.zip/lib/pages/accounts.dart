import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Accounts extends StatefulWidget {
  const Accounts({super.key});

  @override
  State<Accounts> createState() => _AccountsState();
}

class _AccountsState extends State<Accounts> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        title: Text(
          "Account",
          style: TextStyle(color: Theme.of(context).accentColor),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Text(
                    "Login in to get exclusic offers",
                    style: TextStyle(
                        fontSize: 16, color: Theme.of(context).accentColor),
                  ),
                ),
                Spacer(),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    width: 80,
                    child: ElevatedButton(
                      style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all(
                              Color.fromARGB(255, 31, 91, 196))),
                      onPressed: () {
                        Navigator.of(context, rootNavigator: true)
                            .pushNamed("/login");
                      },
                      child: Text('Log in'),
                    ),
                  ),
                ),
              ],
            ),
            Divider(
              height: 10,
              thickness: 8,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "Account Settings",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Theme.of(context).accentColor,
                    ),
                  ),
                ),
                InkWell(
                  onTap: () {
                    Navigator.of(context, rootNavigator: true)
                        .pushNamed("/languagePage");
                  },
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.translate_outlined,
                            color: Theme.of(context).iconTheme.color),
                      ),
                      SizedBox(
                        height: 50,
                        width: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Select Language",
                          style: TextStyle(
                            fontSize: 15,
                            color: Theme.of(context).accentColor,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.43,
                      ),
                      Icon(Icons.arrow_forward_ios,
                          size: 12, color: Theme.of(context).accentColor),
                    ],
                  ),
                ),
                InkWell(
                  onTap: () {
                    Navigator.of(context, rootNavigator: true).pushNamed(
                      "/notification",
                    );
                  },
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.edit_notifications_outlined,
                                                        color: Theme.of(context).iconTheme.color),
                      ),
                      SizedBox(
                        height: 50,
                        width: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Notification Settings",
                          style: TextStyle(
                            fontSize: 15,
                            color: Theme.of(context).accentColor,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.36,
                      ),
                      Icon(Icons.arrow_forward_ios,
                          size: 12, color: Theme.of(context).accentColor),
                    ],
                  ),
                ),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        
                        Icons.support_agent_outlined,
                                                      color: Theme.of(context).iconTheme.color),
                    ),
                    SizedBox(
                      height: 50,
                      width: 10,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        "Help Center",
                        style: TextStyle(
                          fontSize: 15,
                          color: Theme.of(context).accentColor,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.52,
                    ),
                    Icon(Icons.arrow_forward_ios,
                        size: 12, color: Theme.of(context).accentColor),
                  ],
                ),
              ],
            ),
            Divider(
              height: 10,
              thickness: 8,
            ),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      "Earn With Flipkart",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Theme.of(context).accentColor,
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.storefront_outlined,
                                                        color: Theme.of(context).iconTheme.color),
                      ),
                      SizedBox(
                        height: 50,
                        width: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Sell on Flipkart",
                          style: TextStyle(
                              fontSize: 15,
                              color: Theme.of(context).accentColor),
                        ),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.47,
                      ),
                      Icon(Icons.arrow_forward_ios,
                          size: 12, color: Theme.of(context).accentColor),
                    ],
                  ),
                ],
              ),
            ),
            Divider(
              height: 10,
              thickness: 8,
            ),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      "Feedback & Information",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Theme.of(context).accentColor),
                    ),
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.description_outlined,
                                                        color: Theme.of(context).iconTheme.color),
                      ),
                      SizedBox(
                        height: 50,
                        width: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Terms, Policies and Licenses",
                          style: TextStyle(
                              fontSize: 15,
                              color: Theme.of(context).accentColor),
                        ),
                      ),
                      SizedBox(width: MediaQuery.of(context).size.width * 0.21),
                      Icon(Icons.arrow_forward_ios,
                          size: 12, color: Theme.of(context).accentColor),
                    ],
                  ),
                ],
              ),
            ),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Icon(Icons.help_outline,
                                                  color: Theme.of(context).iconTheme.color),
                ),
                SizedBox(
                  height: 50,
                  width: 10,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "Browse FAQs",
                    style: TextStyle(
                        fontSize: 15, color: Theme.of(context).accentColor),
                  ),
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.50,
                ),
                Icon(Icons.arrow_forward_ios,
                    size: 12, color: Theme.of(context).accentColor),
              ],
            ),
            Container(),
            Divider(
              height: 100,
              thickness: 90,
            ),
          ],
        ),
      ),
    );
  }
}
