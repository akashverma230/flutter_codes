import 'package:flutter/material.dart';
import 'package:skill_risers/pages/usersplash.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: UserSplash(),
  ));
}
 