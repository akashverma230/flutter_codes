import 'package:bmi/screens/screen1.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: 
    MyApp(),
  ));
}
