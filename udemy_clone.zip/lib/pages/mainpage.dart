import 'package:flutter/material.dart';
import 'package:skill_risers/pages/secondpage.dart';
import 'package:skill_risers/utils/apiclient.dart';
import 'package:skill_risers/utils/usernavigationbar.dart';

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  Apiclient _client = Apiclient();
  List<dynamic> courses = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _callapi();
  }

  _callapi() async {
    final courseslist = await _client.getdata();
    setState(() {
      courses = courseslist;
    });
    print('data of courses is');
    print(courses);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: UserNavigationBar(),
      appBar: AppBar(
        backgroundColor: Colors.white,
        actions: [
          GestureDetector(
              onTap: () {},
              child: Center(
                child: Text(
                  'Sign in',
                  style: TextStyle(color: Colors.grey, fontSize: 20),
                ),
              ))
        ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Image.network(
              'https://d2gg9evh47fn9z.cloudfront.net/1600px_COLOURBOX35647358.jpg'),
          SizedBox(
            height: 10,
          ),
          Text(
            'Learning that fits',
            style: TextStyle(fontSize: 20),
          ),
          Text('Skills for your present (and future)',
              style: TextStyle(fontSize: 20)),
          SizedBox(
            height: 20,
          ),
          Text('Featured',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
          // Flexible(
          //     child: FutureBuilder(
          //         future: _client.getdata(),
          //         builder: (context, snapshot) {
          //           if (snapshot.hasError) {
          //             return Text('Something went Wrong');
          //           } else if (snapshot.hasData) {
          //             return GridView.count(
          //               crossAxisCount: 2,
          //               children: [
          //                 GridTile(
          //                     child: Column(
          //                   children: [
          //                     Image.network(snapshot.data!["courseImage"])
          //                   ],
          //                 ))
          //               ],
          //             );
          //           } else {
          //             return CircularProgressIndicator();
          //           }
          //         })),
          Expanded(
            child: GridView.builder(
                shrinkWrap: true,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2),
                itemCount: courses.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        GestureDetector(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          SecondPage(courses, index)));
                            },
                            child: Card(
                              
                                child: Image.network(
                              courses[index]["courseImage"],
                              fit: BoxFit.fill,
                            ))),
                         Text(courses[index]["title"])
                      ],
                    ),
                  );
                }),
          ),
// UserNavigationBar()
        ],
      ),
    );
  }
}
